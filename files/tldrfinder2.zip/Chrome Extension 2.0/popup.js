function click(e) {
  chrome.tabs.executeScript(null,
      {code:"document.body.style.backgroundColor='" + e.target.id + "'"});
  window.close();
}
function full(arr){
    for (var i = 0; i < arr.length; i++) {
        if(typeof arr[i] == 'undefined' || arr[i] == null){
            return false;
        }
    }
    return true;
}
//instantiate variables here for debugging purposes
var pageURL;
var response;
var create;
var query = "";
var post = "";
var summ = "";
var ts, at, dm, len, sm;
//only begin processes if extension and page are loaded
document.addEventListener('DOMContentLoaded', function (tab) {
chrome.storage.sync.get(['tldrsub', 'autotldr', 'darkmode', 'length', 'smmry', 'past', 'apikey'], function(data){
ts = data.tldrsub;
at = data.autotldr;
dm = data.darkmode;
len = data.length;
sm = data.smmry;
ps = data.past;
apikey = data.apikey;
if(typeof ts == "undefined"){
    var a = {};
    chrome.storage.sync.set({'tldrsub':true});
    chrome.storage.sync.set({'autotldr':true});
    chrome.storage.sync.set({'darkmode':false});
    chrome.storage.sync.set({'smmry':false});
    chrome.storage.sync.set({'length':5});
    chrome.storage.sync.set({'past':a});
    ts = true;
    at = true;
    dm = false;
    sm = false;
}
if(dm){
    $("body").css("background-image", "url(bgblack.png)");
    $("#submit").css("background-image", "url(bg.png)");
    $("#submit").css("color", "black");
    $("body").css("color", "white");
    $("#found").css("color", "#2af771");
    $("a").css("color", "#28c9ff");
}
var retVal="";
var ajax;
var user = "";
var activeTabId;
//get URL from tab
chrome.tabs.query({'active': true}, function (tabs) {
    pageURL = tabs[0].url;
});
//onclick function for 'Find TL;DR' button
document.getElementById("submit").onclick=function(){
//show loading icon and clear all other elements after click
if(pageURL.substring(0, 3) == "htt"){
$("#where").html("Initiating primary search...");
$("#load").attr("src", "gears.gif");
$("#result").html("");
$("#date").html("");
$("#username").text("");
$("#username").attr("href", "");
query = pageURL;
//first Ajax request to find original reddit post from article URL
ajax = $.ajax({
    url:"https://www.reddit.com/search.json?q="+query+"&limit=1",
    success:function(resp){
            //make sure preemptive requests do not get through
            if(typeof resp.data != "undefined" || typeof resp[0].data != "undefined"){
            if(resp[0] != undefined){
                post = resp[0].data.children[0].data.title;
            }
            else{
                post = resp.data.children[0].data.title;
            }
var query2 = "https://www.reddit.com/r/autotldr/search.json?q="+post+"&restrict_sr=on&limit=1";
//second Ajax request, this time to find the summary post in r/autotldr from original post title
if(at){
$.ajax({
    url:query2,
    success:function(r){
        $("#where").html("Searching through automatic summaries...");
        if(r.data.children.length != 0){
        response = r;
        var date = new Date(r.data.children[0].data.created*1000);
        var text = r.data.children[0].data.selftext;
        var title = r.data.children[0].data.title;
        var name = r.data.children[0].data.author;
        var ups = r.data.children[0].data.ups;
        var permalink = r.data.children[0].data.url;
        //make sure titles are the same
        if(post.toLowerCase() == title.toLowerCase())
        {
            summ = text.substring(text.indexOf("*****") + 6, text.indexOf("[**Summ") - 9);
            retVal=summ.split(" ");
            summ = summ.replace(/\&amp\;/g,"&");
            summ = summ.replace(/\&gt\;/g, "<br><br>");
            
            //send summary and other info to html elements
            $("#load").attr("src", "");
            $('#result').html(summ);
            $("#where").html("");
            //$("#notfound").html("\u2713"+" Summary found!")
            $("#found").html("~(\u02D8\u25BE\u02D8~)    "+" Summary found!")
            $("#date").html("<br>"+ups+" upvotes<br><br>TL;DR created "+(date.getMonth()+ 1)+"/"+date.getDate()+"/"+date.getFullYear()+" by ");
            $("#username").text(name);
            $("#permalink").text("Permanent link to this summary");
            $("#permalink").attr("href", permalink);
            $("#username").attr("href", "https://www.reddit.com/u/"+name);
            $("#submit").attr("hidden", true);
            
        }
        else{
            $("#where").html("");
            if(sm){
                summarize();
            }
            else{
            $("#submit").attr("disabled", "true");
            $("#submit").css("background-color", "red");
            $("#notfound").html(";-;" + " Could not find summary");
            $("#submit").css("background-image", "");
            $("#load").attr("src", "");
            }
        }
        }
        else{
            // $("#submit").attr("disabled", "true");
            // $("#submit").css("background-color", "red");
            // $("#notfound").html(";-;" + " Could not find summary");
            // $("#load").attr("src", "");
            if(ts){
                $("#where").html("Now searching through user-created summaries...");
                tldrsub();
            }
            else{
                if(sm){
                    summarize();
                }
                else{
                $("#notfound").html(";-;" + " Could not find summary");
                $("#where").html("");
                $("#submit").attr("disabled", "true");
                $("#submit").css("background-color", "red");
                $("#submit").css("background-image", "");
                $("#submit").css("color", "white");
                $("#load").attr("src", "");
            }
            }
        }
    },
    //check if error is thrown, only resubmit if 503 error (service unavailable), as these errors are usually resolved with a resubmit
    error: function(err){
        if(typeof err != "undefined" && err.status == 503){
            document.getElementById("submit").click();
        }
    }
})
}
else{
    tldrsub();
}
}
//if no summary is found, update elements accordingly
else{
        if(sm){
            summarize();
        }
        else{
        $("#notfound").html(";-;" + " Could not find summary");
        $("#where").html("");
        $("#submit").attr("disabled", "true");
        $("#submit").css("background-color", "red");
        $("#submit").css("background-image", "");
        $("#submit").css("color", "white");
        $("#load").attr("src", "");
        }
    }
    }   
});
}
else{
        $("#notfound").html("\u0CA0_\u0CA0" + " Invalid page URL");
        $("#submit").attr("disabled", "true");
        $("#submit").css("background-image", "");
        $("#submit").css("background-color", "red");
        $("#submit").css("color", "white");
        $("#load").attr("src", "");
    }
    }
function tldrsub(){
$.ajax({
    url:"https://www.reddit.com/search.json?q="+pageURL,
    success:function(r){
        var i = 0;
        if(typeof r[0] != "undefined" && r[0].data.children.length != 0){
        while(i < r[0].data.children.length - 1 && r[0].data.children[i].data.subreddit != "tldrsub"){
            i++;
        }
        if(r[0].data.children[i].data.subreddit != "tldrsub"){
            console.log("incorrect subreddit");
            $("#submit").attr("disabled", "true");
            $("#submit").css("background-color", "red");
            $("#submit").css("background-image", "");
            $("#where").html("");
            $("#load").attr("src", "");
            if(sm){
                summarize();
            }
            else{
                $("#notfound").html(";-;" + " Could not find summary");
            }
        }
        else{
        response = r;
        var date = new Date(r[0].data.children[i].data.created*1000);
        var text = r[1].data.children[i].data.body;
        var title = r[0].data.children[i].data.title;
        var name = r[0].data.children[i].data.author;
        var ups = r[0].data.children[i].data.ups;
        var permalink = r[0].data.children[i].data.url;
        console.log(text);
            $("#load").attr("src", "");
            $('#result').html(text);
            $("#where").html("");
            //$("#notfound").html("\u2713"+" Summary found!")
            $("#found").html("~(\u02D8\u25BE\u02D8~)    "+" Summary found!<br><br>")
            if(ups == 1){
                $("#date").html("<br>"+ups+" upvote<br><br>TL;DR created "+(date.getMonth()+ 1)+"/"+date.getDate()+"/"+date.getFullYear()+" by ");
            }
            else{
                $("#date").html("<br>"+ups+" upvotes<br><br>TL;DR created "+(date.getMonth()+ 1)+"/"+date.getDate()+"/"+date.getFullYear()+" by ");
            }
            $("#username").text(name);
            $("#permalink").text("Permanent link to this summary");
            $("#permalink").attr("href", permalink);
            $("#username").attr("href", "https://www.reddit.com/u/"+name);
            $("#submit").attr("hidden", true);
        }
    }
    else if(typeof r[0] == "undefined"){
        console.log("r", r);
        if(r.length != 0){
        var array = r.data.children;
        console.log(array);
        var i = 0;
        while(i < array.length - 1 && array[i].data.subreddit != "tldrsub"){
            i++;
        }
        console.log(i, array[i].data.subreddit);
        var url = "https://www.reddit.com"+array[i].data.permalink+".json";
        $.ajax({
            url:url,
            success:function(r){
                if(r[0].data.children[0].data.subreddit != "tldrsub"){
                console.log("incorrect subreddit");
                $("#submit").attr("disabled", "true");
                $("#submit").css("background-color", "red");
                $("#submit").css("background-image", "");
                $("#where").html("");
                $("#load").attr("src", "");
                if(sm){
                    summarize();
                }
                else{
                    $("#notfound").html(";-;" + " Could not find summary");
                }
                }
                else{
                response = r;
                var date = new Date(r[1].data.children[0].data.created*1000);
                var text = r[1].data.children[0].data.body;
                var title = r[0].data.children[0].data.title;
                var name = r[1].data.children[0].data.author;
                var ups = r[0].data.children[0].data.ups;
                var permalink = "https://reddit.com"+r[0].data.children[0].data.permalink + r[1].data.children[0].data.id;
                console.log(text, date, permalink);
                    $("#load").attr("src", "");
                    text = text.replace(/\n/g,"<br>");
                    $('#result').html(text);
                    //$("#notfound").html("\u2713"+" Summary found!")
                    $("#found").html("~(\u02D8\u25BE\u02D8~)    "+" Summary found!<br><br>");
                    $("#where").html("");
                    if(ups == 1){
                        $("#date").html("<br>"+ups+" upvote<br><br>TL;DR created "+(date.getMonth()+ 1)+"/"+date.getDate()+"/"+date.getFullYear()+" by ");
                    }
                    else{
                        $("#date").html("<br>"+ups+" upvotes<br><br>TL;DR created "+(date.getMonth()+ 1)+"/"+date.getDate()+"/"+date.getFullYear()+" by ");
                    }
                            $("#username").text(name);
                    $("#permalink").text("Permanent link to this summary");
                    $("#permalink").attr("href", permalink);
                    $("#username").attr("href", "https://www.reddit.com/u/"+name);
                    $("#submit").attr("hidden", true);
                }
            }

        });
    }
    }

    
    else{
        console.log("no results")
        $("#where").html("");
        $("#submit").attr("disabled", "true");
        $("#submit").css("background-color", "red");
        $("#notfound").html(";-;" + " Could not find summary");
        $("#submit").css("background-image", "");
        $("#load").attr("src", "");
        if(sm){
                summarize();
        }
    }
    },
    //check if error is thrown, only resubmit if 503 error (service unavailable), as these errors are usually resolved with a resubmit
    error: function(err){
        if(typeof err != "undefined" && err.status == 503){
            document.getElementById("submit").click();
        }
    }
})
}
function summarize(){
    $("#where").html("Creating summary...");
    $("#load").attr("src", "gears.gif");
    var length = parseInt(len) + 4;
    var url = "http://api.smmry.com/&SM_API_KEY="+apikey+"&SM_LENGTH="+length+"&SM_URL="+pageURL;
    console.log(url);
    $.ajax( {
        url:url,
        success:function(r){
            var content = r.sm_api_content;
            content = content.replace(/\.\s/g, ".<br><br>");
            $("#load").attr("src", "");
            $("#where").html("");
            $("#submit").attr("hidden", true);
            $("#found").html("~(\u02D8\u25BE\u02D8~)    "+" Summary created!<br><br>");
            $("#result").html(content);
            console.log(r.sm_api_limitation);
            $("#permalink").text("Download this summary (.txt file)");
            document.getElementById("permalink").onclick=function(){
                download(r.sm_api_title);
            }
        }
    });
}
function summarizetest(){
    console.log("Summary here");
}
function download(title){
    var a = document.body.appendChild(
        document.createElement("a")
    );
    var out = document.getElementById("result").innerHTML;
    a.download = "summary.html";
    a.href = "data:text/html," +"<span style='font-weight: bold;'>"+ title + "</span><br><br>" + out; // Grab the HTML
    a.click(); // Trigger a click on the element
}
})
})
