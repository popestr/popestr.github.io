-----------------------------------------------------------------------------------------------------------------------------

How to use TL;DR Finder

-----------------------------------------------------------------------------------------------------------------------------

Open Chrome, and enter "chrome://extensions" in your address bar.

Check the box labeled "Enable developer extensions" and then click "Load unpacked extension".

In the folder selection, navigate to the extracted folder containing this text file and press OK.

The extension is now installed! Click the new icon on any webpage, and if there is a TL;DR for that page, the extension will
find it.

If you wish to access the summary at a permanent link, the extension will provide one under the summary.

-----------------------------------------------------------------------------------------------------------------------------

How it Works

-----------------------------------------------------------------------------------------------------------------------------

The Chrome extension gets the URL of the current tab, then uses the Reddit API to search for the link on Reddit.  After it 
finds the Reddit post, it does another search (exclusively on the r/autotldr subreddit that we get summaries from) to get 
the summary from a post on r/autotldr.  Because the formatting on each post is the same, we can get the summary from the JSON 
and cut out unnecessary text before and after the actual summary.  After we have the text we want it gets put in a div in the 
extension's popup.html.  If no post for the link is found on r/autotldr, the extension notifies the user.  

-----------------------------------------------------------------------------------------------------------------------------




TL;DR Finder 2.0 � 2017 Ryan Pope


