var t;
var a;
var d;
function full(arr){
	for (var i = 0; i < arr.length; i++) {
		if(typeof arr[i] == 'undefined' || arr[i] == null){
			return false;
		}
	}
	return true;
}
window.onload=function(){
	chrome.storage.sync.get(['tldrsub', 'autotldr', 'darkmode', 'length', 'smmry', 'apikey'], function(data){
		//console.log("data", data.tldrsub, data.autotldr);
		t = data.tldrsub;
		a = data.autotldr;
		d = data.darkmode;
		l = data.length;
		s = data.smmry;
		k = data.apikey;
		if(t){
			$("#tldrsub").prop("checked", true);
		}
		if(a){
			$("#autotldr").prop("checked", true);
		}
		if(d){
			$("#darkmode").prop("checked", true);
		}
		if(s){
			$("#smmry").prop("checked", true);
			$("#sl").prop("hidden", false);
			$("#length").prop("hidden", false);
			$("#ak").prop("hidden", false);
		}
		// if(!a && !t){
		// 	$("#tldrsub").prop("checked", true);
		// 	var ts = $("#tldrsub").prop("checked");
		// 	var at = $("#autotldr").prop("checked");
		// 	chrome.storage.sync.set({'tldrsub':ts});
		// 	chrome.storage.sync.set({'autotldr':at});
		// }
		document.getElementById("length").selectedIndex = "" + l;
		$("#ak").val(k);
	})

document.getElementById("checks").onchange=function(){
	var ts = $("#tldrsub").prop("checked");
	var at = $("#autotldr").prop("checked");
	var dm = $("#darkmode").prop("checked");
	var sm = $("#smmry").prop("checked");
	if(sm){
		$("#sl").prop("hidden", false);
		$("#length").prop("hidden", false);
		$("#ak").prop("hidden", false);
	}
	else if(!sm){
		$("#sl").prop("hidden", true);
		$("#length").prop("hidden", true);
		$("#ak").prop("hidden", true);
	}
	var len = $("#length").val();
	var ak = $("#ak").val();
	// if(!(ts||at)){
	// 	$("#tldrsub").prop("checked", true);
	// 	ts = true;
	// }
	console.log(ts, at, dm, sm);
	chrome.storage.sync.set({'tldrsub':ts});
	chrome.storage.sync.set({'autotldr':at});
	chrome.storage.sync.set({'darkmode':dm});
	chrome.storage.sync.set({'smmry':sm});
	chrome.storage.sync.set({'length':len});
	chrome.storage.sync.set({'apikey':ak});
	$("#saved").html("Changes saved.");
	setTimeout(killsave, 2500);
	}
document.getElementById("logo").ondragstart = function() { return false; };
function killsave(){
	$("#saved").html("");
}
}
