function ajax(){
$.ajax({
    url:"https://www.reddit.com/search.json?q=http://www.cnn.com/2017/01/27/us/florida-school-shooting-plot/index.html",
    success:function(r){
        console.log(r);
        var i = 0;
        if(typeof r[0] != "undefined" && r[0].data.children.length != 0){
        while(i < r[0].data.children.length - 1 && r[0].data.children[i].data.subreddit != "tldrsub"){
            i++;
        }
        if(r[0].data.children[i].data.subreddit != "tldrsub"){
            console.log("incorrect subreddit");
            // $("#submit").attr("disabled", "true");
            // $("#submit").css("background-color", "red");
            // $("#notfound").html(";-;" + " Could not find summary");
            // $("#load").attr("src", "");
        }
        else{
        response = r;
        var date = new Date(r[0].data.children[i].data.created*1000);
        var text = r[1].data.children[i].data.body;
        var title = r[0].data.children[i].data.title;
        var name = r[0].data.children[i].data.author;
        var ups = r[0].data.children[i].data.ups;
        var permalink = r[0].data.children[i].data.url;
        console.log(text);
            // $("#load").attr("src", "");
            // $('#result').html(text);
            // //$("#notfound").html("\u2713"+" Summary found!")
            // $("#notfound").html("~(\u02D8\u25BE\u02D8~)    "+" Summary found!")
            // $("#notfound").css("color", "green");
            // $("#date").html("<br>"+ups+" upvotes<br><br>TL;DR created "+(date.getMonth()+ 1)+"/"+date.getDate()+"/"+date.getFullYear()+" by ");
            // $("#username").text(name);
            // $("#permalink").text("Permanent link to this summary");
            // $("#permalink").attr("href", permalink);
            // $("#username").attr("href", "https://www.reddit.com/u/"+name);
            // $("#submit").attr("hidden", true);
        }
    }
    else if(typeof r[0] == "undefined"){
        var array = r.data.children;
        console.log(array);
        var i = 0;
        while(i < array.length && array[i].data.subreddit != "tldrsub"){
            i++;
        }
        console.log(i, array[i].data.subreddit);
        var url = "https://www.reddit.com"+array[i].data.permalink+".json";
        $.ajax({
            url:url,
            success:function(r){
                if(r[0].data.children[0].data.subreddit != "tldrsub"){
                console.log("incorrect subreddit");
                // $("#submit").attr("disabled", "true");
                // $("#submit").css("background-color", "red");
                // $("#notfound").html(";-;" + " Could not find summary");
                // $("#load").attr("src", "");
                }
                else{
                response = r;
                var date = new Date(r[1].data.children[0].data.created*1000);
                var text = r[1].data.children[0].data.body;
                var title = r[0].data.children[0].data.title;
                var name = r[0].data.children[0].data.author;
                var ups = r[0].data.children[0].data.ups;
                var permalink = "https://reddit.com"+r[0].data.children[0].data.permalink;
                console.log(text, date, permalink);
                    // $("#load").attr("src", "");
                    // $('#result').html(text);
                    // //$("#notfound").html("\u2713"+" Summary found!")
                    // $("#notfound").html("~(\u02D8\u25BE\u02D8~)    "+" Summary found!")
                    // $("#notfound").css("color", "green");
                    // $("#date").html("<br>"+ups+" upvotes<br><br>TL;DR created "+(date.getMonth()+ 1)+"/"+date.getDate()+"/"+date.getFullYear()+" by ");
                    // $("#username").text(name);
                    // $("#permalink").text("Permanent link to this summary");
                    // $("#permalink").attr("href", permalink);
                    // $("#username").attr("href", "https://www.reddit.com/u/"+name);
                    // $("#submit").attr("hidden", true);
                }
            }

        });
    }

    
    else{
        console.log("no results")
        // $("#submit").attr("disabled", "true");
        // $("#submit").css("background-color", "red");
        // $("#notfound").html(";-;" + " Could not find summary");
        // $("#load").attr("src", "");
    }
    },
    //check if error is thrown, only resubmit if 503 error (service unavailable), as these errors are usually resolved with a resubmit
    error: function(err){
        if(typeof err != "undefined" && err.status == 503){
            //document.getElementById("submit").click();
        }
    }
})
}